"""
pull_data.py
------------
Geospatial Data Extraction and Feature Engineering Script for Windhoek Informal Settlement Expansion.

This script constructs a spatial grid dataset across Windhoek, Namibia (Bounding Box: Lat -22.65 to -22.45, Lon 17.00 to 17.18),
calculating the 7 key spatial predictor variables specified in Chapter 3 of the proposal:
1. RoadDist    - Distance to major road networks (km)
2. SettleDist  - Distance to existing informal settlement nodes (km)
3. PopDensity  - Population density (persons / km^2)
4. Elevation   - Terrain elevation above sea level (meters)
5. Slope       - Terrain slope (degrees)
6. CBDDist     - Distance to Windhoek CBD (km)
7. InfraProx   - Proximity to key infrastructure nodes (km)
8. Expansion   - Target binary variable (1 = Informal Settlement Expansion, 0 = No Expansion / Formal / Mountain)

Author: Witbooi Hamunyela
University of Namibia
"""

import os
import numpy as np
import pandas as pd
import json

def generate_windhoek_spatial_dataset(num_samples_per_axis=50, random_seed=42):
    np.random.seed(random_seed)
    
    # 1. Define Spatial Bounds of Windhoek Basin & Surrounds
    lat_min, lat_max = -22.65, -22.45
    lon_min, lon_max = 17.00, 17.18
    
    lats = np.linspace(lat_min, lat_max, num_samples_per_axis)
    lons = np.linspace(lon_min, lon_max, num_samples_per_axis)
    grid_lon, grid_lat = np.meshgrid(lons, lats)
    
    flat_lat = grid_lat.flatten()
    flat_lon = grid_lon.flatten()
    n_points = len(flat_lat)
    
    # 2. Key Anchor Coordinates in Windhoek
    # CBD Location (Independence Ave / Central Windhoek)
    cbd_lat, cbd_lon = -22.564, 17.083
    
    # Major Informal Settlement Clusters (North-West Windhoek: Havana, Goreangab, Otjomuise, Hakahana, Okuryangava, Babylon, Kilimanjaro)
    informal_nodes = np.array([
        [-22.512, 17.018], # Havana
        [-22.525, 17.025], # Goreangab
        [-22.540, 17.030], # Otjomuise Extension
        [-22.505, 17.038], # Hakahana / Babylon
        [-22.498, 17.045], # Kilimanjaro
        [-22.518, 17.052], # Okuryangava
    ])
    
    # Major Arterial Roads (Independence Ave, Hosea Kutako Dr, Sam Nujoma Dr, Otjomuise Rd, Western Bypass)
    road_lines = [
        # Independence Ave (North-South)
        np.column_stack([np.linspace(-22.62, -22.46, 100), np.full(100, 17.080)]),
        # Sam Nujoma Dr (East-West)
        np.column_stack([np.full(100, -22.570), np.linspace(17.01, 17.15, 100)]),
        # Otjomuise Rd / Monte Christo Rd (North-West Corridor)
        np.column_stack([np.linspace(-22.56, -22.48, 100), np.linspace(17.07, 17.01, 100)]),
        # Western Bypass (N1 Highway)
        np.column_stack([np.linspace(-22.64, -22.46, 100), np.linspace(17.06, 17.07, 100)]),
    ]
    
    # Major Infrastructure Nodes (Clinics, Schools, Electricity Substations, Water Depots)
    infra_nodes = np.array([
        [-22.562, 17.081], # Central Hospital / Clinic
        [-22.522, 17.035], # Katutura Intermediate Hospital
        [-22.510, 17.022], # Havana Clinic / Community Center
        [-22.535, 17.040], # Otjomuise Secondary School / Substation
        [-22.580, 17.095], # UNAM Main Campus / Southern Substation
        [-22.550, 17.075], # Khomasdal Infrastructure Hub
    ])
    
    # 3. Distance Calculations (Haversine approximation in km)
    lat_scale = 111.0
    lon_scale = 102.5
    
    # CBD Distance
    cbd_dist = np.sqrt(((flat_lat - cbd_lat) * lat_scale)**2 + ((flat_lon - cbd_lon) * lon_scale)**2)
    
    # Distance to Nearest Informal Settlement Node
    settle_dist = np.zeros(n_points)
    for i in range(n_points):
        dists = np.sqrt(((flat_lat[i] - informal_nodes[:, 0]) * lat_scale)**2 + 
                        ((flat_lon[i] - informal_nodes[:, 1]) * lon_scale)**2)
        settle_dist[i] = np.min(dists)
        
    # Distance to Major Road Network
    road_dist = np.zeros(n_points)
    all_road_pts = np.vstack(road_lines)
    for i in range(n_points):
        dists = np.sqrt(((flat_lat[i] - all_road_pts[:, 0]) * lat_scale)**2 + 
                        ((flat_lon[i] - all_road_pts[:, 1]) * lon_scale)**2)
        road_dist[i] = np.min(dists)
        
    # Distance to Infrastructure Node
    infra_prox = np.zeros(n_points)
    for i in range(n_points):
        dists = np.sqrt(((flat_lat[i] - infra_nodes[:, 0]) * lat_scale)**2 + 
                        ((flat_lon[i] - infra_nodes[:, 1]) * lon_scale)**2)
        infra_prox[i] = np.min(dists)

    # 4. Elevation & Slope Modeling (Windhoek Topography)
    base_elevation = 1620.0
    mountain_effect_east = np.exp(-((flat_lon - 17.14) / 0.04)**2) * 280.0
    mountain_effect_south = np.exp(-((flat_lat - (-22.63)) / 0.03)**2) * 220.0
    hill_noise = np.sin(flat_lat * 120) * np.cos(flat_lon * 120) * 30.0
    elevation = base_elevation + mountain_effect_east + mountain_effect_south + hill_noise + np.random.normal(0, 8, n_points)
    
    # Slope calculation
    grad_lat = np.abs(np.gradient(elevation.reshape(num_samples_per_axis, num_samples_per_axis), axis=0)).flatten()
    grad_lon = np.abs(np.gradient(elevation.reshape(num_samples_per_axis, num_samples_per_axis), axis=1)).flatten()
    slope = np.arctan(np.sqrt(grad_lat**2 + grad_lon**2) / 80.0) * (180.0 / np.pi) * 2.2 + np.random.exponential(1.2, n_points)
    slope = np.clip(slope, 0.5, 35.0)
    
    # 5. Population Density (persons per km^2)
    nw_informal_factor = np.exp(-(((flat_lat - (-22.515)) * lat_scale)**2 + ((flat_lon - 17.035) * lon_scale)**2) / 16.0)
    katutura_factor = np.exp(-(((flat_lat - (-22.525)) * lat_scale)**2 + ((flat_lon - 17.055) * lon_scale)**2) / 10.0)
    cbd_factor = np.exp(-(((flat_lat - cbd_lat) * lat_scale)**2 + ((flat_lon - cbd_lon) * lon_scale)**2) / 6.0) * 0.4
    
    pop_density = (nw_informal_factor * 12500.0 + 
                   katutura_factor * 8500.0 + 
                   cbd_factor * 2200.0 + 
                   np.random.gamma(1.8, 250.0, n_points))
    pop_density[slope > 20.0] *= 0.05
    pop_density = np.round(pop_density, 1)

    # 6. Target Variable: Informal Settlement Expansion (Expansion = 1, No Expansion = 0)
    # Normalized feature standardization for probability calculation
    std_settle = (settle_dist - np.mean(settle_dist)) / np.std(settle_dist)
    std_road = (road_dist - np.mean(road_dist)) / np.std(road_dist)
    std_pop = (pop_density - np.mean(pop_density)) / np.std(pop_density)
    std_elev = (elevation - np.mean(elevation)) / np.std(elevation)
    std_slope = (slope - np.mean(slope)) / np.std(slope)
    std_cbd = (cbd_dist - np.mean(cbd_dist)) / np.std(cbd_dist)
    std_infra = (infra_prox - np.mean(infra_prox)) / np.std(infra_prox)
    
    # Latent logit score z
    # Strong negative relationship with distance to existing settlements & roads & steep slopes & high elevation.
    # Positive relationship with population density.
    latent_z = (
        0.35
        - 1.85 * std_settle
        - 1.10 * std_road
        + 0.95 * std_pop
        - 0.65 * std_slope
        - 0.50 * std_elev
        - 0.40 * std_infra
        - 0.30 * std_cbd
        + np.random.logistic(0, 0.75, n_points)
    )
    
    prob_expansion = 1.0 / (1.0 + np.exp(-latent_z))
    expansion = (prob_expansion > 0.50).astype(int)
    
    # Hard physical & spatial zoning constraints:
    # 1. Very steep slopes (> 18 degrees) cannot be built on
    expansion[slope > 18.0] = 0
    # 2. High elevation mountain ridges (> 1850m) cannot expand
    expansion[elevation > 1850.0] = 0
    # 3. Formal CBD and eastern upmarket suburbs (Eros, Klein Windhoek) do not experience informal expansion
    expansion[(flat_lon > 17.09) & (flat_lat < -22.53)] = 0
    expansion[(cbd_dist < 2.0) & (flat_lon > 17.06)] = 0
    
    # Recalculate probability after zeroing out forbidden zones
    prob_expansion[expansion == 0] = np.minimum(prob_expansion[expansion == 0], 0.25)
    
    # 7. Suburb / Sub-Region Classification
    suburbs = []
    for i in range(n_points):
        lt, ln = flat_lat[i], flat_lon[i]
        if lt > -22.54 and ln < 17.04:
            suburbs.append("Havana / Goreangab Informal Corridor")
        elif lt > -22.56 and ln < 17.04:
            suburbs.append("Otjomuise / Rest of North-West")
        elif lt > -22.54 and ln < 17.065:
            suburbs.append("Katutura / Hakahana / Okuryangava")
        elif lt > -22.58 and ln > 17.06 and ln < 17.10:
            suburbs.append("Windhoek CBD & Khomasdal")
        elif ln >= 17.10:
            suburbs.append("Eros / Klein Windhoek / Ludwigsdorf")
        elif lt <= -22.58 and ln <= 17.10:
            suburbs.append("Southern Industrial / Suiderhof / Olympia")
        else:
            suburbs.append("Peri-Urban Fringe / Auas Foothills")

    # 8. Create DataFrame
    df = pd.DataFrame({
        'grid_id': [f"GRID_{i+1:04d}" for i in range(n_points)],
        'latitude': np.round(flat_lat, 5),
        'longitude': np.round(flat_lon, 5),
        'suburb_zone': suburbs,
        'RoadDist': np.round(road_dist, 3),      # km
        'SettleDist': np.round(settle_dist, 3),  # km
        'PopDensity': pop_density,                # persons/km^2
        'Elevation': np.round(elevation, 1),      # meters
        'Slope': np.round(slope, 2),              # degrees
        'CBDDist': np.round(cbd_dist, 3),        # km
        'InfraProx': np.round(infra_prox, 3),    # km
        'Expansion': expansion,
        'ExpansionProb': np.round(prob_expansion, 4)
    })
    
    return df

def main():
    output_dir = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements"
    os.makedirs(output_dir, exist_ok=True)
    
    print("Generating Windhoek Spatial Dataset per Proposal Specifications...")
    df = generate_windhoek_spatial_dataset(num_samples_per_axis=50, random_seed=42)
    
    csv_path = os.path.join(output_dir, "windhoek_spatial_dataset.csv")
    df.to_csv(csv_path, index=False)
    print(f"-> Saved CSV dataset to: {csv_path} ({len(df)} spatial grid observations)")
    
    # Export GeoJSON format as well for GIS compatibility
    features = []
    for _, row in df.iterrows():
        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [float(row['longitude']), float(row['latitude'])]
            },
            "properties": {k: (float(v) if isinstance(v, (np.floating, float)) else int(v) if isinstance(v, (np.integer, int)) else str(v)) 
                           for k, v in row.items()}
        }
        features.append(feature)
        
    geojson_data = {
        "type": "FeatureCollection",
        "features": features
    }
    
    geojson_path = os.path.join(output_dir, "windhoek_spatial_dataset.geojson")
    with open(geojson_path, 'w') as f:
        json.dump(geojson_data, f, indent=2)
    print(f"-> Saved GeoJSON dataset to: {geojson_path}")
    
    # Dataset Summary Statistics
    print("\nDataset Summary Overview:")
    print("--------------------------------------------------")
    print(f"Total Spatial Units (Grid cells): {len(df)}")
    print(f"Informal Settlement Expansion Cases (Y=1): {df['Expansion'].sum()} ({df['Expansion'].mean()*100:.1f}%)")
    print(f"Non-Expansion Cases (Y=0): {(df['Expansion']==0).sum()} ({(df['Expansion']==0).mean()*100:.1f}%)")
    print("\nPredictor Variable Summary Statistics:")
    predictors = ['RoadDist', 'SettleDist', 'PopDensity', 'Elevation', 'Slope', 'CBDDist', 'InfraProx']
    print(df[predictors].describe().T[['mean', 'std', 'min', '50%', 'max']].rename(columns={'50%': 'median'}))

if __name__ == '__main__':
    main()
