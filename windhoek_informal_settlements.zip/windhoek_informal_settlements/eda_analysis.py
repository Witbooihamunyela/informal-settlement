"""
eda_analysis.py
---------------
Exploratory Data Analysis and Publication-Quality Chart Generation for Windhoek Spatial Dataset.

Outputs generated in charts/ folder:
1. correlation_heatmap.png            - Correlation matrix of 7 spatial predictors + expansion
2. predictor_boxplots.png             - Boxplots comparing predictors across Expansion (0 vs 1)
3. spatial_distribution_map.png       - Spatial scatter/grid map of Windhoek showing expansion zones
4. suburb_expansion_breakdown.png     - Expansion rate breakdown across Windhoek sub-regions

Author: Witbooi Hamunyela
University of Namibia
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set publication style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['figure.titlesize'] = 14

def run_eda(csv_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    df = pd.read_csv(csv_path)
    
    predictors = ['RoadDist', 'SettleDist', 'PopDensity', 'Elevation', 'Slope', 'CBDDist', 'InfraProx']
    
    # ----------------------------------------------------
    # 1. Summary Statistics Table Export
    # ----------------------------------------------------
    print("=== SUMMARY STATISTICS BY EXPANSION STATUS ===")
    overall = df[predictors].describe().T[['mean', 'std', 'min', '50%', 'max']].rename(columns={'50%': 'median'})
    print(overall)
    
    # Save overall summary to CSV
    overall.to_csv(os.path.join(output_dir, "descriptive_statistics.csv"))
    
    # Group by expansion summary
    exp_summary = df.groupby('Expansion')[predictors].mean().T
    exp_summary.columns = ['No Expansion (0) Mean', 'Expansion (1) Mean']
    exp_summary['Difference'] = exp_summary['Expansion (1) Mean'] - exp_summary['No Expansion (0) Mean']
    exp_summary.to_csv(os.path.join(output_dir, "group_means_comparison.csv"))
    
    # ----------------------------------------------------
    # 2. Correlation Heatmap
    # ----------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 7.5))
    corr_vars = predictors + ['Expansion']
    corr_matrix = df[corr_vars].corr()
    
    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", vmin=-1.0, vmax=1.0,
                square=True, linewidths=0.8, cbar_kws={"shrink": 0.8}, ax=ax)
    
    ax.set_title("Pearson Correlation Matrix of Spatial Variables", pad=15, fontweight='bold')
    plt.tight_layout()
    heatmap_path = os.path.join(output_dir, "correlation_heatmap.png")
    plt.savefig(heatmap_path, dpi=300)
    plt.close()
    print(f"-> Saved correlation heatmap to: {heatmap_path}")
    
    # ----------------------------------------------------
    # 3. Predictor Boxplots by Expansion Class
    # ----------------------------------------------------
    fig, axes = plt.subplots(2, 4, figsize=(16, 8.5))
    axes = axes.flatten()
    
    palette_dict = {0: '#2b5c8f', 1: '#d95f02', '0': '#2b5c8f', '1': '#d95f02'}
    
    for i, col in enumerate(predictors):
        ax = axes[i]
        sns.boxplot(x='Expansion', y=col, hue='Expansion', data=df, palette=palette_dict, ax=ax, width=0.45, legend=False)
        ax.set_xticklabels(['No Expansion (0)', 'Expansion (1)'])
        ax.set_xlabel('')
        ax.set_title(col, fontweight='bold')
        
    # Remove empty 8th subplot
    fig.delaxes(axes[7])
    
    fig.suptitle("Comparison of Spatial Predictor Distributions by Settlement Expansion Status", fontweight='bold', y=0.98)
    plt.tight_layout()
    boxplot_path = os.path.join(output_dir, "predictor_boxplots.png")
    plt.savefig(boxplot_path, dpi=300)
    plt.close()
    print(f"-> Saved boxplots to: {boxplot_path}")
    
    # ----------------------------------------------------
    # 4. Spatial Map of Windhoek Grid & Expansion Risk
    # ----------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 8))
    
    colors_exp = np.where(df['Expansion'] == 1, '#d95f02', '#2b5c8f')
    scatter = ax.scatter(df['longitude'], df['latitude'], c=colors_exp, s=25, alpha=0.85, edgecolors='none')
    
    # Mark CBD
    ax.plot(17.083, -22.564, 'k*', markersize=14, label='Windhoek CBD')
    
    # Annotate key informal hubs
    ax.annotate('Havana', xy=(17.018, -22.512), xytext=(17.00, -22.49),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=5),
                fontweight='bold', color='#800000')
    ax.annotate('Goreangab', xy=(17.025, -22.525), xytext=(17.00, -22.54),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=5),
                fontweight='bold', color='#800000')
    ax.annotate('Katutura', xy=(17.055, -22.525), xytext=(17.06, -22.50),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=5),
                fontweight='bold', color='#333333')
    
    # Custom legend
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', label='No Expansion (0)', markerfacecolor='#2b5c8f', markersize=8),
        Line2D([0], [0], marker='o', color='w', label='Expansion (1)', markerfacecolor='#d95f02', markersize=8),
        Line2D([0], [0], marker='*', color='w', label='Windhoek CBD', markerfacecolor='k', markersize=12)
    ]
    ax.legend(handles=legend_elements, loc='lower right')
    
    ax.set_title("Spatial Distribution of Informal Settlement Expansion in Windhoek", fontweight='bold', pad=12)
    ax.set_xlabel("Longitude (°E)")
    ax.set_ylabel("Latitude (°S)")
    ax.grid(True, linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    spatial_map_path = os.path.join(output_dir, "spatial_distribution_map.png")
    plt.savefig(spatial_map_path, dpi=300)
    plt.close()
    print(f"-> Saved spatial distribution map to: {spatial_map_path}")
    
    # ----------------------------------------------------
    # 5. Sub-Region Breakdown Bar Chart
    # ----------------------------------------------------
    fig, ax = plt.subplots(figsize=(10, 5.5))
    
    suburb_stats = df.groupby('suburb_zone')['Expansion'].agg(['count', 'sum', 'mean']).reset_index()
    suburb_stats['mean_pct'] = suburb_stats['mean'] * 100.0
    suburb_stats = suburb_stats.sort_values(by='mean_pct', ascending=True)
    
    bars = ax.barh(suburb_stats['suburb_zone'], suburb_stats['mean_pct'], color='#d95f02', edgecolor='black', height=0.6)
    
    for bar in bars:
        width = bar.get_width()
        ax.text(width + 1.0, bar.get_y() + bar.get_height()/2, f"{width:.1f}%", 
                va='center', ha='left', fontweight='bold', fontsize=10)
        
    ax.set_xlim(0, max(suburb_stats['mean_pct']) + 12)
    ax.set_xlabel("Informal Settlement Expansion Rate (%)", fontweight='bold')
    ax.set_title("Observed Informal Settlement Expansion Risk by Windhoek Sub-Region", fontweight='bold', pad=12)
    
    plt.tight_layout()
    suburb_chart_path = os.path.join(output_dir, "suburb_expansion_breakdown.png")
    plt.savefig(suburb_chart_path, dpi=300)
    plt.close()
    print(f"-> Saved suburb breakdown chart to: {suburb_chart_path}")
    
    print("EDA completed successfully.")

if __name__ == '__main__':
    csv_path = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements\windhoek_spatial_dataset.csv"
    output_dir = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements\charts"
    run_eda(csv_path, output_dir)
