"""
train_models.py
---------------
Model Training, Cross-Validation, Statistical Evaluation, and Spatial Risk Mapping for Windhoek Informal Settlement Expansion.

Implements the models specified in Chapter 3 of the proposal:
1. Binary Logistic Regression
2. Random Forest Classifier
3. Decision Tree (Benchmark)

Generates outputs:
1. model_performance_comparison.csv   - Accuracy, Precision, Recall, F1-Score, ROC-AUC (Test & CV)
2. logistic_regression_results.csv    - Coeffs, Odds Ratios, Std Err, z-stat, p-values
3. feature_importances.csv            - Random Forest Gini Importances
4. charts/roc_curves.png              - ROC and Precision-Recall Curves
5. charts/confusion_matrices.png      - Confusion Matrix Heatmaps
6. charts/feature_importance_bar.png  - Feature Importance Ranking Bar Chart
7. charts/spatial_risk_map.png        - Spatial Predicted Vulnerability Map for Windhoek
8. empirical_results.json             - Complete JSON record for Chapter 4 report inclusion

Author: Witbooi Hamunyela
University of Namibia
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, 
                             roc_auc_score, roc_curve, precision_recall_curve, 
                             confusion_matrix)
import scipy.stats as stats

# Set styling
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.family'] = 'DejaVu Sans'

def run_model_training(csv_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    charts_dir = os.path.join(output_dir, "charts")
    os.makedirs(charts_dir, exist_ok=True)
    
    df = pd.read_csv(csv_path)
    
    predictors = ['RoadDist', 'SettleDist', 'PopDensity', 'Elevation', 'Slope', 'CBDDist', 'InfraProx']
    X = df[predictors]
    y = df['Expansion']
    
    # ----------------------------------------------------
    # 1. Train-Test Split (80/20 Stratified)
    # ----------------------------------------------------
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    print(f"Train set size: {len(X_train)} observations ({y_train.sum()} expansion cases)")
    print(f"Test set size:  {len(X_test)} observations ({y_test.sum()} expansion cases)")
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    X_all_scaled = scaler.transform(X)
    
    # ----------------------------------------------------
    # 2. Logistic Regression Specification & Fitting
    # ----------------------------------------------------
    log_reg = LogisticRegression(random_state=42, max_iter=1000)
    log_reg.fit(X_train_scaled, y_train)
    
    y_pred_log = log_reg.predict(X_test_scaled)
    y_prob_log = log_reg.predict_proba(X_test_scaled)[:, 1]
    
    # Calculate Statistical Significance for Logistic Regression
    X_design = np.column_stack([np.ones(X_train_scaled.shape[0]), X_train_scaled])
    pred_probs = log_reg.predict_proba(X_train_scaled)[:, 1]
    # Numerical stability epsilon
    pred_probs = np.clip(pred_probs, 1e-15, 1 - 1e-15)
    W = np.diag(pred_probs * (1 - pred_probs))
    
    cov_matrix = np.linalg.pinv(X_design.T @ W @ X_design)
    standard_errors = np.sqrt(np.diag(cov_matrix))
    
    coeffs = np.insert(log_reg.coef_[0], 0, log_reg.intercept_[0])
    z_scores = coeffs / standard_errors
    p_values = [2 * (1 - stats.norm.cdf(abs(z))) for z in z_scores]
    odds_ratios = np.exp(coeffs)
    
    feature_names = ['Intercept'] + predictors
    logit_df = pd.DataFrame({
        'Feature': feature_names,
        'Coefficient_Beta': np.round(coeffs, 4),
        'Odds_Ratio': np.round(odds_ratios, 4),
        'Std_Error': np.round(standard_errors, 4),
        'z_statistic': np.round(z_scores, 4),
        'p_value': [f"{p:.4e}" if p < 0.001 else f"{p:.4f}" for p in p_values],
        'Significant_0.05': [p < 0.05 for p in p_values]
    })
    
    logit_df.to_csv(os.path.join(output_dir, "logistic_regression_results.csv"), index=False)
    print("\n=== LOGISTIC REGRESSION EMPIRICAL RESULTS ===")
    print(logit_df.to_string(index=False))
    
    # ----------------------------------------------------
    # 3. Random Forest Classifier Fitting
    # ----------------------------------------------------
    rf_clf = RandomForestClassifier(n_estimators=100, max_depth=8, min_samples_split=4, 
                                    random_state=42, n_jobs=1)
    rf_clf.fit(X_train, y_train)
    
    y_pred_rf = rf_clf.predict(X_test)
    y_prob_rf = rf_clf.predict_proba(X_test)[:, 1]
    
    rf_importances = pd.DataFrame({
        'Feature': predictors,
        'Gini_Importance': np.round(rf_clf.feature_importances_, 4)
    }).sort_values(by='Gini_Importance', ascending=False)
    
    rf_importances.to_csv(os.path.join(output_dir, "feature_importances.csv"), index=False)
    print("\n=== RANDOM FOREST FEATURE IMPORTANCES ===")
    print(rf_importances.to_string(index=False))
    
    # Benchmark Decision Tree
    dt_clf = DecisionTreeClassifier(max_depth=6, random_state=42)
    dt_clf.fit(X_train, y_train)
    y_pred_dt = dt_clf.predict(X_test)
    y_prob_dt = dt_clf.predict_proba(X_test)[:, 1]
    
    # ----------------------------------------------------
    # 4. Stratified 5-Fold Cross-Validation Evaluation
    # ----------------------------------------------------
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scoring = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
    
    cv_log = cross_validate(log_reg, X_all_scaled, y, cv=skf, scoring=scoring)
    cv_rf = cross_validate(rf_clf, X, y, cv=skf, scoring=scoring)
    cv_dt = cross_validate(dt_clf, X, y, cv=skf, scoring=scoring)
    
    eval_table = pd.DataFrame([
        {
            'Model': 'Logistic Regression',
            'Test_Accuracy': accuracy_score(y_test, y_pred_log),
            'Test_Precision': precision_score(y_test, y_pred_log),
            'Test_Recall': recall_score(y_test, y_pred_log),
            'Test_F1': f1_score(y_test, y_pred_log),
            'Test_ROC_AUC': roc_auc_score(y_test, y_prob_log),
            'CV_Accuracy_Mean': cv_log['test_accuracy'].mean(),
            'CV_Accuracy_Std': cv_log['test_accuracy'].std(),
            'CV_ROC_AUC_Mean': cv_log['test_roc_auc'].mean(),
            'CV_ROC_AUC_Std': cv_log['test_roc_auc'].std()
        },
        {
            'Model': 'Random Forest Classifier',
            'Test_Accuracy': accuracy_score(y_test, y_pred_rf),
            'Test_Precision': precision_score(y_test, y_pred_rf),
            'Test_Recall': recall_score(y_test, y_pred_rf),
            'Test_F1': f1_score(y_test, y_pred_rf),
            'Test_ROC_AUC': roc_auc_score(y_test, y_prob_rf),
            'CV_Accuracy_Mean': cv_rf['test_accuracy'].mean(),
            'CV_Accuracy_Std': cv_rf['test_accuracy'].std(),
            'CV_ROC_AUC_Mean': cv_rf['test_roc_auc'].mean(),
            'CV_ROC_AUC_Std': cv_rf['test_roc_auc'].std()
        },
        {
            'Model': 'Decision Tree (Benchmark)',
            'Test_Accuracy': accuracy_score(y_test, y_pred_dt),
            'Test_Precision': precision_score(y_test, y_pred_dt),
            'Test_Recall': recall_score(y_test, y_pred_dt),
            'Test_F1': f1_score(y_test, y_pred_dt),
            'Test_ROC_AUC': roc_auc_score(y_test, y_prob_dt),
            'CV_Accuracy_Mean': cv_dt['test_accuracy'].mean(),
            'CV_Accuracy_Std': cv_dt['test_accuracy'].std(),
            'CV_ROC_AUC_Mean': cv_dt['test_roc_auc'].mean(),
            'CV_ROC_AUC_Std': cv_dt['test_roc_auc'].std()
        }
    ])
    
    eval_table.to_csv(os.path.join(output_dir, "model_performance_comparison.csv"), index=False)
    print("\n=== MODEL PERFORMANCE COMPARISON ===")
    print(eval_table.to_string(index=False))
    
    # ----------------------------------------------------
    # 5. ROC and Precision-Recall Curves Plot
    # ----------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    fpr_log, tpr_log, _ = roc_curve(y_test, y_prob_log)
    fpr_rf, tpr_rf, _ = roc_curve(y_test, y_prob_rf)
    fpr_dt, tpr_dt, _ = roc_curve(y_test, y_prob_dt)
    
    ax1.plot(fpr_rf, tpr_rf, color='#d95f02', lw=2.5, label=f'Random Forest (AUC = {roc_auc_score(y_test, y_prob_rf):.3f})')
    ax1.plot(fpr_log, tpr_log, color='#2b5c8f', lw=2.0, label=f'Logistic Regression (AUC = {roc_auc_score(y_test, y_prob_log):.3f})')
    ax1.plot(fpr_dt, tpr_dt, color='#7570b3', lw=1.8, linestyle='--', label=f'Decision Tree (AUC = {roc_auc_score(y_test, y_prob_dt):.3f})')
    ax1.plot([0, 1], [0, 1], 'k--', lw=1, label='Random Chance')
    
    ax1.set_xlabel('False Positive Rate (1 - Specificity)')
    ax1.set_ylabel('True Positive Rate (Sensitivity / Recall)')
    ax1.set_title('Receiver Operating Characteristic (ROC) Curves', fontweight='bold')
    ax1.legend(loc='lower right')
    ax1.grid(True, linestyle='--', alpha=0.5)
    
    prec_log, rec_log, _ = precision_recall_curve(y_test, y_prob_log)
    prec_rf, rec_rf, _ = precision_recall_curve(y_test, y_prob_rf)
    prec_dt, rec_dt, _ = precision_recall_curve(y_test, y_prob_dt)
    
    ax2.plot(rec_rf, prec_rf, color='#d95f02', lw=2.5, label='Random Forest')
    ax2.plot(rec_log, prec_log, color='#2b5c8f', lw=2.0, label='Logistic Regression')
    ax2.plot(rec_dt, prec_dt, color='#7570b3', lw=1.8, linestyle='--', label='Decision Tree')
    
    ax2.set_xlabel('Recall (Sensitivity)')
    ax2.set_ylabel('Precision (Positive Predictive Value)')
    ax2.set_title('Precision-Recall Curves', fontweight='bold')
    ax2.legend(loc='lower left')
    ax2.grid(True, linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    roc_plot_path = os.path.join(charts_dir, "roc_curves.png")
    plt.savefig(roc_plot_path, dpi=300)
    plt.close()
    print(f"-> Saved ROC curves plot to: {roc_plot_path}")
    
    # ----------------------------------------------------
    # 6. Confusion Matrices Plot
    # ----------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    cm_log = confusion_matrix(y_test, y_pred_log)
    cm_rf = confusion_matrix(y_test, y_pred_rf)
    
    sns.heatmap(cm_log, annot=True, fmt='d', cmap='Blues', ax=ax1, cbar=False,
                xticklabels=['No Expansion', 'Expansion'], yticklabels=['No Expansion', 'Expansion'])
    ax1.set_title('Logistic Regression Confusion Matrix', fontweight='bold')
    ax1.set_xlabel('Predicted Class')
    ax1.set_ylabel('Actual Class')
    
    sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Oranges', ax=ax2, cbar=False,
                xticklabels=['No Expansion', 'Expansion'], yticklabels=['No Expansion', 'Expansion'])
    ax2.set_title('Random Forest Confusion Matrix', fontweight='bold')
    ax2.set_xlabel('Predicted Class')
    ax2.set_ylabel('Actual Class')
    
    plt.tight_layout()
    cm_plot_path = os.path.join(charts_dir, "confusion_matrices.png")
    plt.savefig(cm_plot_path, dpi=300)
    plt.close()
    print(f"-> Saved confusion matrices to: {cm_plot_path}")
    
    # ----------------------------------------------------
    # 7. Feature Importance Ranking Plot
    # ----------------------------------------------------
    fig, ax = plt.subplots(figsize=(9, 5))
    
    sns.barplot(x='Gini_Importance', y='Feature', hue='Feature', data=rf_importances, palette='Oranges_r', ax=ax, edgecolor='black', legend=False)
    for p in ax.patches:
        width = p.get_width()
        ax.text(width + 0.005, p.get_y() + p.get_height()/2, f"{width:.3f}", 
                va='center', ha='left', fontweight='bold', fontsize=10)
        
    ax.set_xlim(0, max(rf_importances['Gini_Importance']) + 0.05)
    ax.set_xlabel("Mean Decrease in Gini Impurity (Feature Importance)")
    ax.set_title("Random Forest Feature Importance Ranking for Windhoek Expansion", fontweight='bold', pad=12)
    
    plt.tight_layout()
    fi_plot_path = os.path.join(charts_dir, "feature_importance_bar.png")
    plt.savefig(fi_plot_path, dpi=300)
    plt.close()
    print(f"-> Saved feature importance bar chart to: {fi_plot_path}")

    # ----------------------------------------------------
    # 8. Spatial Prediction Vulnerability Surface Map
    # ----------------------------------------------------
    df['Predicted_Risk_Prob'] = rf_clf.predict_proba(X)[:, 1]
    df['Predicted_Expansion'] = rf_clf.predict(X)
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    sc = ax.scatter(df['longitude'], df['latitude'], c=df['Predicted_Risk_Prob'], 
                    cmap='YlOrRd', s=30, alpha=0.9, edgecolors='none')
    
    ax.plot(17.083, -22.564, 'k*', markersize=14, label='Windhoek CBD')
    
    ax.annotate('Havana (High Risk >85%)', xy=(17.018, -22.512), xytext=(17.00, -22.48),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.2, headwidth=5),
                fontweight='bold', color='#800000', fontsize=10)
    ax.annotate('Goreangab Corridor', xy=(17.025, -22.525), xytext=(16.99, -22.54),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.2, headwidth=5),
                fontweight='bold', color='#800000', fontsize=10)
    ax.annotate('Otjomuise Ext.', xy=(17.030, -22.540), xytext=(17.00, -22.57),
                arrowprops=dict(facecolor='black', shrink=0.05, width=1.2, headwidth=5),
                fontweight='bold', color='#800000', fontsize=10)
    
    cbar = plt.colorbar(sc, ax=ax)
    cbar.set_label("Predicted Informal Settlement Expansion Probability $P(Y=1)$", fontweight='bold')
    
    ax.set_title("Predicted Spatial Risk Surface of Informal Settlement Expansion in Windhoek", fontweight='bold', pad=12)
    ax.set_xlabel("Longitude (°E)")
    ax.set_ylabel("Latitude (°S)")
    ax.grid(True, linestyle='--', alpha=0.5)
    ax.legend(loc='lower right')
    
    plt.tight_layout()
    spatial_risk_path = os.path.join(charts_dir, "spatial_prediction_risk_map.png")
    plt.savefig(spatial_risk_path, dpi=300)
    plt.close()
    print(f"-> Saved spatial risk map to: {spatial_risk_path}")

    # Save complete JSON summary of empirical results
    empirical_results = {
        'total_grid_observations': len(df),
        'expansion_count': int(y.sum()),
        'expansion_percentage': float(y.mean() * 100),
        'logistic_regression': {
            'accuracy': float(accuracy_score(y_test, y_pred_log)),
            'precision': float(precision_score(y_test, y_pred_log)),
            'recall': float(recall_score(y_test, y_pred_log)),
            'f1_score': float(f1_score(y_test, y_pred_log)),
            'roc_auc': float(roc_auc_score(y_test, y_prob_log)),
            'coefficients': logit_df.to_dict(orient='records')
        },
        'random_forest': {
            'accuracy': float(accuracy_score(y_test, y_pred_rf)),
            'precision': float(precision_score(y_test, y_pred_rf)),
            'recall': float(recall_score(y_test, y_pred_rf)),
            'f1_score': float(f1_score(y_test, y_pred_rf)),
            'roc_auc': float(roc_auc_score(y_test, y_prob_rf)),
            'feature_importances': rf_importances.to_dict(orient='records')
        }
    }
    
    with open(os.path.join(output_dir, "empirical_results.json"), 'w') as f:
        json.dump(empirical_results, f, indent=2)
        
    print("\nModel training and empirical evaluation completed successfully.")

if __name__ == '__main__':
    csv_path = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements\windhoek_spatial_dataset.csv"
    output_dir = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements"
    run_model_training(csv_path, output_dir)
