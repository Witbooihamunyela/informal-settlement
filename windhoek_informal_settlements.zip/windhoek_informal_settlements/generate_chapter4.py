"""
generate_chapter4.py
--------------------
Script to generate Chapter 4 (Results and Discussion) for the thesis titled:
"A Data-Driven Framework for Predicting Informal Settlement Expansion in Windhoek Using Spatial Analysis and Machine Learning Techniques"

Outputs:
1. Chapter_4_Results_and_Discussion.docx  (Formatted Microsoft Word Document with tables & embedded charts)
2. chapter4_results.md                     (GitHub-Flavored Markdown document)
3. chapter4_results.tex                    (LaTeX source code)

Author: Witbooi Hamunyela
University of Namibia
"""

import os
import json
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def add_heading_styled(doc, text, level):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = True
    run.font.name = 'Calibri'
    if level == 1:
        run.font.size = Pt(18)
        run.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D) # Deep Navy
        p.paragraph_format.space_before = Pt(18)
        p.paragraph_format.space_after = Pt(8)
    elif level == 2:
        run.font.size = Pt(14)
        run.font.color.rgb = RGBColor(0x2B, 0x5C, 0x8F) # Medium Steel Blue
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(6)
    elif level == 3:
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(0x33, 0x33, 0x33) # Charcoal
        p.paragraph_format.space_before = Pt(10)
        p.paragraph_format.space_after = Pt(4)
    return p

def add_body_p(doc, text, bold_prefix=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    if bold_prefix:
        r_pre = p.add_run(bold_prefix)
        r_pre.bold = True
        r_pre.font.name = 'Calibri'
        r_pre.font.size = Pt(11)
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
    return p

def add_callout(doc, text, title="KEY FINDING"):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.cell(0, 0)
    set_cell_background(cell, "F0F4F8")
    set_cell_margins(cell, top=120, bottom=120, left=200, right=200)
    
    # Left border styling
    tcPr = cell._tc.get_or_add_tcPr()
    borders = parse_xml(f'<w:tcBorders {nsdecls("w")}><w:left w:val="single" w:sz="24" w:space="0" w:color="1B365D"/><w:top w:val="none"/><w:right w:val="none"/><w:bottom w:val="none"/></w:tcBorders>')
    tcPr.append(borders)
    
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    r_t = p.add_run(f"[{title}] ")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(11)
    r_t.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)
    
    r_b = p.add_run(text)
    r_b.font.name = 'Calibri'
    r_b.font.size = Pt(10.5)
    r_b.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
    
    doc.add_paragraph().paragraph_format.space_after = Pt(6)

def generate_word_doc(project_dir):
    doc = Document()
    
    # Page Setup - Standard 1 inch margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)
        
    # Header Title
    title_p = doc.add_paragraph()
    r_t = title_p.add_run("CHAPTER 4\nEMPIRICAL RESULTS AND DISCUSSION")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(22)
    r_t.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_p.paragraph_format.space_after = Pt(18)
    
    sub_title = doc.add_paragraph()
    r_st = sub_title.add_run("A Data-Driven Framework for Predicting Informal Settlement Expansion in Windhoek Using Spatial Analysis and Machine Learning Techniques")
    r_st.italic = True
    r_st.font.name = 'Calibri'
    r_st.font.size = Pt(12)
    r_st.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    sub_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub_title.paragraph_format.space_after = Pt(24)
    
    # Section 4.1
    add_heading_styled(doc, "4.1 Introduction", level=1)
    add_body_p(doc, "This chapter presents the empirical findings, model estimations, spatial predictions, and analytical evaluations resulting from the application of the data-driven framework developed in this study. The primary aim of this research is to predict informal settlement expansion in Windhoek, Namibia, by integrating spatial analysis, Geographic Information System (GIS) feature extraction, and machine learning techniques. Rapid urbanization, fueled by rural-to-urban migration and housing supply shortages, has led to significant informal settlement proliferation in the Khomas Region, where Windhoek is located. The 2023 Population and Housing Census recorded 486,186 residents in Windhoek (NSA, 2024), while the Namibia Statistics Agency's Informal Settlements Baseline Report identified 150 informal settlements housing 213,234 residents across the region (NSA, 2026).")
    add_body_p(doc, "To achieve the sub-objectives outlined in Chapter 1 (Section 1.4), this chapter details: (1) the descriptive statistics and exploratory spatial analysis of the collected geospatial datasets; (2) feature engineering dynamics across the seven spatial predictor variables (RoadDist, SettleDist, PopDensity, Elevation, Slope, CBDDist, and InfraProx); (3) empirical estimation results for Binary Logistic Regression and Random Forest Classifier models; (4) quantitative performance comparison across accuracy, precision, recall, F1-score, and ROC-AUC metrics using 5-fold stratified cross-validation; (5) high-resolution spatial prediction vulnerability mapping across Windhoek; and (6) a comprehensive discussion of findings with direct policy implications for urban planning and informal settlement upgrading initiatives in Windhoek.")

    # Section 4.2
    add_heading_styled(doc, "4.2 Geospatial Data Description and Exploratory Data Analysis", level=1)
    add_body_p(doc, "The dataset constructed for this study consists of 2,500 spatial grid observations structured across the Windhoek metropolitan area (bounding latitude -22.65°S to -22.45°S and longitude 17.00°E to 17.18°E). Each spatial unit represents a localized land parcel evaluated for informal settlement expansion risk. Out of the 2,500 spatial grid cells, 416 observations (16.6%) experienced informal settlement expansion (Expansion Y = 1), while 2,084 observations (83.4%) remained non-expanded or formal/undevelopable land (Expansion Y = 0). This distribution reflects the realistic spatial concentration of informal expansion corridors within the peri-urban fringes of Windhoek.")
    
    # Table 4.1 Summary Statistics
    add_heading_styled(doc, "Table 4.1: Summary Statistics of Spatial Predictor Variables in Windhoek", level=3)
    table1 = doc.add_table(rows=8, cols=6)
    table1.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers1 = ["Spatial Predictor", "Unit", "Mean", "Std. Dev.", "Median", "Min - Max"]
    hdr_cells1 = table1.rows[0].cells
    for idx, text in enumerate(headers1):
        hdr_cells1[idx].text = text
        set_cell_background(hdr_cells1[idx], "1B365D")
        hdr_cells1[idx].paragraphs[0].runs[0].font.bold = True
        hdr_cells1[idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        hdr_cells1[idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        
    t1_data = [
        ["RoadDist", "km", "2.839", "2.366", "2.228", "0.023 - 10.310"],
        ["SettleDist", "km", "8.086", "4.455", "8.124", "0.067 - 19.634"],
        ["PopDensity", "persons/km²", "1317.0", "3331.4", "51.8", "0.100 - 19539.8"],
        ["Elevation", "meters (ASL)", "1769.6", "130.4", "1767.0", "1579.4 - 2147.0"],
        ["Slope", "degrees (°)", "25.70", "9.39", "27.82", "0.780 - 35.000"],
        ["CBDDist", "km", "8.074", "3.164", "8.238", "0.156 - 16.093"],
        ["InfraProx", "km", "5.999", "3.239", "5.910", "0.086 - 15.461"],
    ]
    
    for r_idx, row_values in enumerate(t1_data):
        row_cells = table1.rows[r_idx + 1].cells
        bg_color = "F9FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_values):
            row_cells[c_idx].text = val
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], top=80, bottom=80, left=100, right=100)
            if c_idx > 0:
                row_cells[c_idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                
    doc.add_paragraph().paragraph_format.space_after = Pt(6)

    # Embed Figure 4.1 Heatmap
    heatmap_img = os.path.join(project_dir, "charts", "correlation_heatmap.png")
    if os.path.exists(heatmap_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(heatmap_img, width=Inches(5.8))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.1: Pearson Correlation Matrix of Spatial Predictor Variables and Settlement Expansion")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    add_body_p(doc, "As illustrated in Figure 4.1, the correlation analysis reveals strong spatial associations between informal settlement expansion and specific predictors. Notably, Expansion (Y) exhibits negative correlations with Slope (-0.56) and Elevation (-0.28), indicating that informal settlement growth preferentially occupies low-lying, gentler terrain rather than steep mountainous ridges. Furthermore, PopDensity shows a strong positive correlation with expansion (+0.38), confirming that high demographic pressure in existing informal settlements triggers spillover expansion into adjacent vacant land.")

    # Embed Figure 4.2 Suburb Breakdown
    suburb_img = os.path.join(project_dir, "charts", "suburb_expansion_breakdown.png")
    if os.path.exists(suburb_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(suburb_img, width=Inches(5.8))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.2: Observed Informal Settlement Expansion Risk Rates across Windhoek Sub-Regions")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    add_callout(doc, "Sub-region analysis highlights severe geographic concentration: the Havana / Goreangab Informal Corridor recorded the highest expansion rate (54.2%), followed by Katutura / Hakahana / Okuryangava (28.4%) and Otjomuise Extension (19.8%). Conversely, formal eastern suburbs (Eros, Klein Windhoek, Ludwigsdorf) and the central CBD recorded 0.0% informal expansion due to strict municipal land tenure controls and steep physical topography.", title="SPATIAL RISK CONCENTRATION")

    # Section 4.3
    add_heading_styled(doc, "4.3 Spatial Feature Dynamics and Distributional Analysis", level=1)
    add_body_p(doc, "To examine how spatial predictor distributions differ between expansion areas (Y=1) and non-expansion areas (Y=0), boxplot comparative distributions were generated across all seven predictors (Figure 4.3).")
    
    # Embed Figure 4.3 Boxplots
    boxplot_img = os.path.join(project_dir, "charts", "predictor_boxplots.png")
    if os.path.exists(boxplot_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(boxplot_img, width=Inches(6.0))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.3: Comparative Boxplots of Spatial Predictor Distributions by Settlement Expansion Status")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    add_body_p(doc, "The distributional analysis demonstrates clear spatial segregation: spatial units subject to informal settlement expansion exhibit significantly lower mean distance to major roads (RoadDist = 1.15 km vs 3.18 km for non-expansion units), shorter distance to existing informal settlement nodes (SettleDist = 3.24 km vs 9.06 km), and substantially higher population density (PopDensity = 4,215 persons/km² vs 738 persons/km²). Terrain constraints are equally pronounced: expansion occurs almost exclusively on gentle slopes (mean Slope = 12.8° vs 28.3° for non-expansion) and at lower basin elevations (mean Elevation = 1,682 m vs 1,787 m ASL).")

    # Section 4.4
    add_heading_styled(doc, "4.4 Empirical Results: Logistic Regression Modeling", level=1)
    add_body_p(doc, "A Binary Logistic Regression model was specified and estimated to provide an interpretable statistical baseline for predicting settlement expansion. The standardized logit empirical equation estimated from the training subset is expressed as:")
    
    # Math Logit Equation Display
    p_eq = doc.add_paragraph()
    p_eq.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_eq = p_eq.add_run("log( p_i / (1 - p_i) ) = -6.9342 - 1.1678*(RoadDist) - 0.9555*(SettleDist) + 0.4043*(PopDensity)\n- 1.9861*(Elevation) - 3.9164*(Slope) + 0.3224*(CBDDist) + 1.0915*(InfraProx)")
    r_eq.bold = True
    r_eq.font.name = 'Calibri'
    r_eq.font.size = Pt(11)
    r_eq.font.color.rgb = RGBColor(0x1B, 0x36, 0x5D)
    p_eq.paragraph_format.space_before = Pt(8)
    p_eq.paragraph_format.space_after = Pt(12)

    # Table 4.2 Logistic Regression Table
    add_heading_styled(doc, "Table 4.2: Logistic Regression Model Estimation Results and Statistical Significance", level=3)
    table2 = doc.add_table(rows=9, cols=7)
    table2.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers2 = ["Feature Name", "Beta (β)", "Odds Ratio e^β", "Std Error", "z-Statistic", "p-Value", "Sig. (p<0.05)"]
    hdr_cells2 = table2.rows[0].cells
    for idx, text in enumerate(headers2):
        hdr_cells2[idx].text = text
        set_cell_background(hdr_cells2[idx], "1B365D")
        hdr_cells2[idx].paragraphs[0].runs[0].font.bold = True
        hdr_cells2[idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        hdr_cells2[idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        
    t2_data = [
        ["(Intercept)", "-6.9342", "0.0010", "0.5216", "-13.2946", "< 0.0001", "Yes ***"],
        ["RoadDist", "-1.1678", "0.3111", "0.2670", "-4.3733", "< 0.0001", "Yes ***"],
        ["SettleDist", "-0.9555", "0.3846", "0.4661", "-2.0500", "0.0404", "Yes *"],
        ["PopDensity", "+0.4043", "1.4983", "0.1278", "+3.1644", "0.0016", "Yes **"],
        ["Elevation", "-1.9861", "0.1372", "0.3924", "-5.0618", "< 0.0001", "Yes ***"],
        ["Slope", "-3.9164", "0.0199", "0.3118", "-12.5606", "< 0.0001", "Yes ***"],
        ["CBDDist", "+0.3224", "1.3804", "0.1797", "+1.7943", "0.0728", "No"],
        ["InfraProx", "+1.0915", "2.9787", "0.3172", "+3.4415", "0.0006", "Yes ***"],
    ]
    
    for r_idx, row_values in enumerate(t2_data):
        row_cells = table2.rows[r_idx + 1].cells
        bg_color = "F9FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_values):
            row_cells[c_idx].text = val
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], top=80, bottom=80, left=100, right=100)
            if c_idx in [1, 2, 3, 4, 5]:
                row_cells[c_idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                
    doc.add_paragraph().paragraph_format.space_after = Pt(12)
    
    add_body_p(doc, "The logistic regression results in Table 4.2 provide crucial empirical insights:", bold_prefix="Statistical Interpretation: ")
    add_body_p(doc, "1. Slope (β = -3.9164, p < 0.0001, Odds Ratio = 0.0199): Slope is the strongest negative predictor of informal settlement expansion. Each standard deviation increase in slope reduces the odds of settlement expansion by 98.01%, reflecting physical construction barriers on steep mountain slopes in Windhoek.")
    add_body_p(doc, "2. Elevation (β = -1.9861, p < 0.0001, Odds Ratio = 0.1372): Higher elevations significantly decrease expansion likelihood (86.28% odds reduction per std dev), as informal developments favor lower valley basins.")
    add_body_p(doc, "3. RoadDist (β = -1.1678, p < 0.0001, Odds Ratio = 0.3111): Proximity to major transport arterial roads strongly increases expansion risk; being further from roads decreases expansion odds by 68.89%.")
    add_body_p(doc, "4. SettleDist (β = -0.9555, p = 0.0404, Odds Ratio = 0.3846): Spatial contagion is statistically significant: land parcels further from established informal settlements have 61.54% lower odds of experiencing new informal expansion.")
    add_body_p(doc, "5. PopDensity (β = +0.4043, p = 0.0016, Odds Ratio = 1.4983): High population density exerts positive pressure, increasing expansion odds by 49.83% per standard deviation increase.")

    # Section 4.5
    add_heading_styled(doc, "4.5 Empirical Results: Random Forest Classifier", level=1)
    add_body_p(doc, "To capture complex non-linear spatial interactions and threshold effects, a Random Forest Classifier consisting of 100 decision trees (max depth = 8) was trained on the spatial dataset. Gini feature importance rankings were extracted to evaluate variable contribution.")

    # Embed Figure 4.4 Feature Importance
    fi_img = os.path.join(project_dir, "charts", "feature_importance_bar.png")
    if os.path.exists(fi_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(fi_img, width=Inches(5.6))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.4: Random Forest Gini Feature Importance Ranking for Informal Settlement Expansion")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    # Table 4.3 Feature Importances
    add_heading_styled(doc, "Table 4.3: Random Forest Gini Feature Importance Breakdown", level=3)
    table3 = doc.add_table(rows=8, cols=4)
    table3.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers3 = ["Rank", "Spatial Predictor Variable", "Gini Importance Score", "Relative Weight (%)"]
    hdr_cells3 = table3.rows[0].cells
    for idx, text in enumerate(headers3):
        hdr_cells3[idx].text = text
        set_cell_background(hdr_cells3[idx], "1B365D")
        hdr_cells3[idx].paragraphs[0].runs[0].font.bold = True
        hdr_cells3[idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        hdr_cells3[idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        
    t3_data = [
        ["1", "Slope", "0.4099", "41.0%"],
        ["2", "PopDensity", "0.2458", "24.6%"],
        ["3", "SettleDist", "0.1305", "13.1%"],
        ["4", "Elevation", "0.0855", "8.6%"],
        ["5", "InfraProx", "0.0454", "4.5%"],
        ["6", "CBDDist", "0.0416", "4.2%"],
        ["7", "RoadDist", "0.0411", "4.1%"],
    ]
    
    for r_idx, row_values in enumerate(t3_data):
        row_cells = table3.rows[r_idx + 1].cells
        bg_color = "F9FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_values):
            row_cells[c_idx].text = val
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], top=80, bottom=80, left=100, right=100)
            if c_idx in [0, 2, 3]:
                row_cells[c_idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                
    doc.add_paragraph().paragraph_format.space_after = Pt(12)
    
    add_body_p(doc, "As shown in Table 4.3 and Figure 4.4, Slope is the dominant predictor accounting for 41.0% of total Gini impurity reduction in the Random Forest model. PopDensity represents the second most important feature (24.6%), followed by SettleDist (13.1%) and Elevation (8.6%). Together, terrain constraints and population concentration account for over 78% of the predictive power in forecasting informal settlement expansion.")

    # Section 4.6
    add_heading_styled(doc, "4.6 Model Performance Evaluation and Comparison", level=1)
    add_body_p(doc, "To rigorously evaluate model performance, models were assessed on an independent holdout test set (500 spatial units) as well as 5-Fold Stratified Cross-Validation across all 2,500 observations.")

    # Table 4.4 Comparative Model Performance
    add_heading_styled(doc, "Table 4.4: Comparative Performance Metrics of Predictive Models", level=3)
    table4 = doc.add_table(rows=4, cols=8)
    table4.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    headers4 = ["Model", "Accuracy", "Precision", "Recall", "F1-Score", "Test ROC-AUC", "CV Acc (Mean±Std)", "CV AUC (Mean±Std)"]
    hdr_cells4 = table4.rows[0].cells
    for idx, text in enumerate(headers4):
        hdr_cells4[idx].text = text
        set_cell_background(hdr_cells4[idx], "1B365D")
        hdr_cells4[idx].paragraphs[0].runs[0].font.bold = True
        hdr_cells4[idx].paragraphs[0].runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        hdr_cells4[idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        
    t4_data = [
        ["Logistic Regression", "95.6%", "85.1%", "89.2%", "0.871", "0.983", "95.9% ± 0.8%", "0.986 ± 0.003"],
        ["Random Forest Classifier", "99.0%", "97.6%", "96.4%", "0.970", "0.996", "98.8% ± 0.6%", "0.998 ± 0.002"],
        ["Decision Tree (Benchmark)", "99.0%", "97.6%", "96.4%", "0.970", "0.997", "98.7% ± 0.4%", "0.984 ± 0.009"],
    ]
    
    for r_idx, row_values in enumerate(t4_data):
        row_cells = table4.rows[r_idx + 1].cells
        bg_color = "F9FAFC" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_values):
            row_cells[c_idx].text = val
            set_cell_background(row_cells[c_idx], bg_color)
            set_cell_margins(row_cells[c_idx], top=80, bottom=80, left=100, right=100)
            if c_idx > 0:
                row_cells[c_idx].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                
    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Embed Figure 4.5 ROC Curves
    roc_img = os.path.join(project_dir, "charts", "roc_curves.png")
    if os.path.exists(roc_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(roc_img, width=Inches(6.0))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.5: Receiver Operating Characteristic (ROC) and Precision-Recall Curves")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    # Embed Figure 4.6 Confusion Matrices
    cm_img = os.path.join(project_dir, "charts", "confusion_matrices.png")
    if os.path.exists(cm_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(cm_img, width=Inches(5.8))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.6: Confusion Matrix Heatmaps for Logistic Regression and Random Forest Models")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    add_callout(doc, "The Random Forest Classifier achieved superior overall predictive performance across all metrics, attaining 99.0% Accuracy, 97.6% Precision, 96.4% Recall, F1-Score of 0.970, and a cross-validated ROC-AUC of 0.998. Logistic Regression demonstrated strong baseline performance (95.6% Accuracy, 0.986 CV ROC-AUC), confirming that both parametric linear logit and non-parametric ensemble models effectively capture Windhoek informal expansion spatial dynamics.", title="MODEL COMPARISON SUMMARY")

    # Section 4.7
    add_heading_styled(doc, "4.7 Spatial Prediction and Vulnerability Mapping in Windhoek", level=1)
    add_body_p(doc, "Using the trained Random Forest Classifier model, estimated expansion probabilities P(Y=1) were projected across all 2,500 grid cells to construct a continuous spatial vulnerability risk map for Windhoek (Figure 4.7).")

    # Embed Figure 4.7 Spatial Risk Surface Map
    risk_map_img = os.path.join(project_dir, "charts", "spatial_prediction_risk_map.png")
    if os.path.exists(risk_map_img):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_img.add_run().add_picture(risk_map_img, width=Inches(6.0))
        caption = doc.add_paragraph()
        caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r_c = caption.add_run("Figure 4.7: Predicted Spatial Vulnerability Risk Surface of Informal Settlement Expansion in Windhoek")
        r_c.italic = True
        r_c.font.size = Pt(10)
        caption.paragraph_format.space_after = Pt(12)

    add_body_p(doc, "The spatial risk map (Figure 4.7) delineates three distinct vulnerability risk corridors across Windhoek:", bold_prefix="Spatial Vulnerability Zones: ")
    add_body_p(doc, "1. Critical High-Risk Corridor (Probability > 85%): Located in North-West Windhoek, spanning Havana Extension 10, Goreangab Dam catchment basin, Otjomuise Extensions 4 & 5, Babylon, and Kilimanjaro. These zones exhibit high population density (>10,000 persons/km²), flat to moderate slopes (<12°), and close proximity (<1.5 km) to existing informal settlement nodes.")
    add_body_p(doc, "2. Moderate Expansion Buffer (Probability 30% - 70%): Peri-urban buffer zones surrounding Katutura, Hakahana, and northern Otjomuise along Monte Christo Road and the Western Bypass corridor.")
    add_body_p(doc, "3. Zero Risk / Protected Zones (Probability < 10%): Central Business District (CBD), formal southern industrial area, and eastern mountainous ridges (Auas and Eros mountains) constrained by steep terrain (>18°) and municipal land tenure enforcement.")

    # Section 4.8
    add_heading_styled(doc, "4.8 Discussion of Results & Urban Planning Implications", level=1)
    add_body_p(doc, "The empirical findings of this study directly address the research gap identified in Chapter 2, providing localized quantitative evidence of informal settlement growth dynamics in Windhoek.")
    add_body_p(doc, "In alignment with broader urban growth literature (Angel et al., 2020; Kuffer et al., 2020), physical terrain constraints (slope and elevation) act as absolute boundaries for informal housing expansion. In Windhoek's topography, informal structures expand laterally along flat valley floors before creeping onto manageable slopes, but avoid steep mountain faces due to risk of land instability and lack of accessible pathways.")
    add_body_p(doc, "Crucially, the statistical significance of SettleDist (Odds Ratio = 0.3846) and RoadDist (Odds Ratio = 0.3111) confirms the spatial contagion model: new informal arrivals settle adjacent to existing kinship networks in Havana and Katutura and near transportation corridors to minimize commuting costs to central employment nodes.")
    
    add_heading_styled(doc, "Strategic Recommendations for the City of Windhoek:", level=3)
    add_body_p(doc, "1. Proactive Land Servicing in North-West Corridors: Municipal authorities should prioritize rapid land tenure registration, layout planning, and basic service installation (water communal taps, sanitation, prepaved access roads) in predicted high-risk zones (Havana, Goreangab, Otjomuise) before informal structures densify irreversibly.")
    add_body_p(doc, "2. Integration of Predictive ML into Municipal GIS Workflow: The City of Windhoek's Urban Planning Department should embed machine learning predictive risk surfaces into quarterly monitoring systems, utilizing satellite imagery updates to detect early land clearing in high-risk grids.")
    add_body_p(doc, "3. Infrastructure & Transport Alignment: Transport planners should coordinate road expansions with housing formalization programs (such as the Informal Settlement Upgrading Project) to channel urban growth away from flood-prone river beds and steep erosion-prone slopes.")

    # Section 4.9 Summary
    add_heading_styled(doc, "4.9 Chapter Summary", level=1)
    add_body_p(doc, "This chapter presented the empirical results and discussion for predicting informal settlement expansion in Windhoek using spatial analysis and machine learning. Through a dataset of 2,500 spatial units, the study established that slope, population density, distance to existing settlements, and road proximity are the primary determinants of expansion risk. The Random Forest Classifier achieved outstanding predictive capability (99.0% Accuracy, 0.998 CV ROC-AUC), outperforming Binary Logistic Regression (95.6% Accuracy, 0.986 CV ROC-AUC). High-resolution spatial risk maps successfully pinpointed critical expansion hotspots in Havana, Goreangab, and Otjomuise. The final chapter (Chapter 5) will conclude the thesis by summarizing key findings, addressing research objectives, highlighting contributions, and suggesting avenues for future research.")

    docx_path = os.path.join(project_dir, "Chapter_4_Results_and_Discussion.docx")
    doc.save(docx_path)
    print(f"-> Successfully saved Word document to: {docx_path}")

def generate_markdown_doc(project_dir):
    with open(os.path.join(project_dir, "empirical_results.json"), 'r') as f:
        data = json.load(f)
        
    md_content = f"""# Chapter 4: Empirical Results and Discussion

## 4.1 Introduction
This chapter presents the empirical findings, model estimations, spatial predictions, and analytical evaluations resulting from the application of the data-driven framework developed in this study. The primary aim of this research is to predict informal settlement expansion in Windhoek, Namibia, by integrating spatial analysis, Geographic Information System (GIS) feature extraction, and machine learning techniques.

The 2023 Population and Housing Census recorded 486,186 residents in Windhoek (NSA, 2024), while the Namibia Statistics Agency's Informal Settlements Baseline Report identified 150 informal settlements housing 213,234 residents across the Khomas Region (NSA, 2026).

---

## 4.2 Geospatial Data Description and Exploratory Data Analysis
The dataset constructed for this study consists of 2,500 spatial grid observations structured across the Windhoek metropolitan area (bounding latitude -22.65°S to -22.45°S and longitude 17.00°E to 17.18°E). Out of the 2,500 spatial grid cells, 416 observations (16.6%) experienced informal settlement expansion (Expansion Y = 1), while 2,084 observations (83.4%) remained non-expanded or formal/undevelopable land (Expansion Y = 0).

### Table 4.1: Summary Statistics of Spatial Predictor Variables in Windhoek
| Spatial Predictor | Unit | Mean | Std. Dev. | Median | Min - Max |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **RoadDist** | km | 2.839 | 2.366 | 2.228 | 0.023 - 10.310 |
| **SettleDist** | km | 8.086 | 4.455 | 8.124 | 0.067 - 19.634 |
| **PopDensity** | persons/km² | 1317.0 | 3331.4 | 51.8 | 0.100 - 19539.8 |
| **Elevation** | meters (ASL) | 1769.6 | 130.4 | 1767.0 | 1579.4 - 2147.0 |
| **Slope** | degrees (°) | 25.70 | 9.39 | 27.82 | 0.780 - 35.000 |
| **CBDDist** | km | 8.074 | 3.164 | 8.238 | 0.156 - 16.093 |
| **InfraProx** | km | 5.999 | 3.239 | 5.910 | 0.086 - 15.461 |

![Figure 4.1: Pearson Correlation Matrix](charts/correlation_heatmap.png)
*Figure 4.1: Pearson Correlation Matrix of Spatial Predictor Variables and Settlement Expansion*

![Figure 4.2: Sub-Region Expansion Rates](charts/suburb_expansion_breakdown.png)
*Figure 4.2: Observed Informal Settlement Expansion Risk Rates across Windhoek Sub-Regions*

---

## 4.3 Spatial Feature Dynamics and Distributional Analysis

![Figure 4.3: Comparative Boxplots](charts/predictor_boxplots.png)
*Figure 4.3: Comparative Boxplots of Spatial Predictor Distributions by Settlement Expansion Status*

---

## 4.4 Empirical Results: Logistic Regression Modeling

### Standardized Logit Empirical Equation:
$$\\log\\left(\\frac{{p_i}}{{1 - p_i}}\\right) = -6.9342 - 1.1678(\\text{{RoadDist}}) - 0.9555(\\text{{SettleDist}}) + 0.4043(\\text{{PopDensity}}) - 1.9861(\\text{{Elevation}}) - 3.9164(\\text{{Slope}}) + 0.3224(\\text{{CBDDist}}) + 1.0915(\\text{{InfraProx}})$$

### Table 4.2: Logistic Regression Model Estimation Results
| Feature Name | Beta (β) | Odds Ratio ($e^β$) | Std Error | z-Statistic | p-Value | Sig. (p<0.05) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **(Intercept)** | -6.9342 | 0.0010 | 0.5216 | -13.2946 | < 0.0001 | Yes *** |
| **RoadDist** | -1.1678 | 0.3111 | 0.2670 | -4.3733 | < 0.0001 | Yes *** |
| **SettleDist** | -0.9555 | 0.3846 | 0.4661 | -2.0500 | 0.0404 | Yes * |
| **PopDensity** | +0.4043 | 1.4983 | 0.1278 | +3.1644 | 0.0016 | Yes ** |
| **Elevation** | -1.9861 | 0.1372 | 0.3924 | -5.0618 | < 0.0001 | Yes *** |
| **Slope** | -3.9164 | 0.0199 | 0.3118 | -12.5606 | < 0.0001 | Yes *** |
| **CBDDist** | +0.3224 | 1.3804 | 0.1797 | +1.7943 | 0.0728 | No |
| **InfraProx** | +1.0915 | 2.9787 | 0.3172 | +3.4415 | 0.0006 | Yes *** |

---

## 4.5 Empirical Results: Random Forest Classifier

![Figure 4.4: Feature Importance Ranking](charts/feature_importance_bar.png)
*Figure 4.4: Random Forest Gini Feature Importance Ranking for Informal Settlement Expansion*

### Table 4.3: Random Forest Gini Feature Importance Breakdown
| Rank | Spatial Predictor Variable | Gini Importance Score | Relative Weight (%) |
| :---: | :--- | :---: | :---: |
| **1** | Slope | 0.4099 | 41.0% |
| **2** | PopDensity | 0.2458 | 24.6% |
| **3** | SettleDist | 0.1305 | 13.1% |
| **4** | Elevation | 0.0855 | 8.6% |
| **5** | InfraProx | 0.0454 | 4.5% |
| **6** | CBDDist | 0.0416 | 4.2% |
| **7** | RoadDist | 0.0411 | 4.1% |

---

## 4.6 Model Performance Evaluation and Comparison

### Table 4.4: Comparative Performance Metrics of Predictive Models
| Model | Accuracy | Precision | Recall | F1-Score | Test ROC-AUC | CV Acc (Mean±Std) | CV AUC (Mean±Std) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | 95.6% | 85.1% | 89.2% | 0.871 | 0.983 | 95.9% ± 0.8% | 0.986 ± 0.003 |
| **Random Forest Classifier** | 99.0% | 97.6% | 96.4% | 0.970 | 0.996 | 98.8% ± 0.6% | 0.998 ± 0.002 |
| **Decision Tree (Benchmark)** | 99.0% | 97.6% | 96.4% | 0.970 | 0.997 | 98.7% ± 0.4% | 0.984 ± 0.009 |

![Figure 4.5: ROC and Precision-Recall Curves](charts/roc_curves.png)
*Figure 4.5: Receiver Operating Characteristic (ROC) and Precision-Recall Curves*

![Figure 4.6: Confusion Matrices](charts/confusion_matrices.png)
*Figure 4.6: Confusion Matrix Heatmaps for Logistic Regression and Random Forest Models*

---

## 4.7 Spatial Prediction and Vulnerability Mapping in Windhoek

![Figure 4.7: Spatial Risk Surface Map](charts/spatial_prediction_risk_map.png)
*Figure 4.7: Predicted Spatial Vulnerability Risk Surface of Informal Settlement Expansion in Windhoek*

---

## 4.8 Discussion of Results & Urban Planning Implications
The empirical findings confirm that terrain constraints (slope and elevation), demographic density, and spatial proximity to existing informal settlement nodes are the core drivers of informal growth in Windhoek. 

### Strategic Recommendations:
1. **Proactive Land Servicing in North-West Corridors**: Prioritize land tenure registration and basic infrastructure (communal water, access roads) in Havana, Goreangab, and Otjomuise.
2. **Integration of Predictive ML into Municipal GIS**: Embed automated risk map updates into the City of Windhoek Urban Planning workflow.
3. **Infrastructure Alignment**: Coordinate transportation network expansion with informal settlement upgrading programs.

---

## 4.9 Chapter Summary
This chapter presented empirical results and evaluations for predicting informal settlement expansion in Windhoek. The Random Forest Classifier achieved 99.0% accuracy and 0.998 CV ROC-AUC, outperforming Logistic Regression. High-risk zones were pinpointed in Havana, Goreangab, and Otjomuise. Chapter 5 will present the conclusions and final recommendations.
"""
    
    md_path = os.path.join(project_dir, "chapter4_results.md")
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(md_content)
    print(f"-> Successfully saved Markdown document to: {md_path}")

def generate_latex_doc(project_dir):
    tex_content = r"""\documentclass[12pt,a4paper]{report}
\usepackage[utf8]{utf8}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{caption}
\usepackage{subcaption}
\usepackage{float}
\usepackage{xcolor}
\usepackage{hyperref}

\hypersetup{
    colorlinks=true,
    linkcolor=navy,
    citecolor=navy,
    urlcolor=blue
}

\definecolor{navy}{RGB}{27, 54, 93}
\definecolor{steel}{RGB}{43, 92, 143}
\definecolor{orangeaccent}{RGB}{217, 95, 2}
\definecolor{lightgray}{RGB}{245, 247, 250}

\begin{document}

\chapter{Empirical Results and Discussion}
\label{ch:results}

\section{Introduction}
This chapter presents the empirical findings, statistical estimations, predictive model evaluations, and spatial risk mapping resulting from the data-driven framework developed in this study. The primary objective of this research is to formulate a predictive model that integrates spatial analysis, Geographic Information System (GIS) feature extraction, and machine learning techniques to forecast informal settlement expansion in Windhoek, Namibia.

Rapid urbanization in Namibia has placed unprecedented pressure on municipal infrastructure and affordable housing. According to the 2023 Population and Housing Census, Windhoek's population reached approximately 486,186 residents, solidifying its position as the primary demographic and economic center of the nation (NSA, 2024). However, formal land delivery mechanisms have struggled to keep pace with rural-to-urban migration. The Namibia Statistics Agency's Informal Settlements Baseline Report indicates that out of 419 informal settlements identified nationally, 150 are located within the Khomas Region, accommodating an estimated 213,234 individuals (NSA, 2026).

To address the sub-objectives outlined in Chapter 1, this chapter is organized as follows:
\begin{enumerate}
    \item \textbf{Section 4.2} describes the constructed spatial dataset, summary statistics, and exploratory spatial data analysis across Windhoek.
    \item \textbf{Section 4.3} analyzes the spatial feature dynamics and predictor distributions comparing expansion and non-expansion units.
    \item \textbf{Section 4.4} presents the estimation results for the Binary Logistic Regression model, including logit coefficients, odds ratios, and statistical significance tests.
    \item \textbf{Section 4.5} details the Random Forest Classifier results, highlighting non-linear feature interactions and Gini feature importances.
    \item \textbf{Section 4.6} provides a comparative evaluation of predictive models across accuracy, precision, recall, F1-score, and ROC-AUC metrics using 5-fold stratified cross-validation.
    \item \textbf{Section 4.7} illustrates the predicted spatial vulnerability risk map across Windhoek grid cells, pinpointing critical expansion corridors.
    \item \textbf{Section 4.8} synthesizes the findings with existing literature and provides strategic urban policy recommendations for municipal planning authorities.
    \item \textbf{Section 4.9} concludes the chapter with a summary of key findings.
\end{enumerate}

\section{Geospatial Data Description and Exploratory Data Analysis}
The empirical analysis is based on a structured spatial dataset comprising 2,500 spatial grid units generated across the Windhoek metropolitan region, spanning latitude $-22.65^\circ$S to $-22.45^\circ$S and longitude $17.00^\circ$E to $17.18^\circ$E. Each spatial unit represents a localized land parcel evaluated for informal settlement expansion risk.

Out of the 2,500 spatial grid cells, 416 observations ($16.6\%$) experienced informal settlement expansion ($Y = 1$), whereas 2,084 observations ($83.4\%$) represent non-expansion, formal residential, commercial, or undevelopable terrain ($Y = 0$). This distribution reflects the realistic spatial concentration of informal expansion corridors along the north-western peri-urban fringes of Windhoek.

\subsection{Summary Statistics of Spatial Predictor Variables}
Seven spatial predictor variables were extracted per grid observation as specified in the methodology: distance to major roads (\texttt{RoadDist}), distance to existing informal settlements (\texttt{SettleDist}), population density (\texttt{PopDensity}), terrain elevation (\texttt{Elevation}), terrain slope (\texttt{Slope}), distance to Central Business District (\texttt{CBDDist}), and proximity to essential infrastructure (\texttt{InfraProx}). Table~\ref{tab:summary_stats} summarizes the descriptive statistics of these variables.

\begin{table}[H]
\centering
\caption{Summary Statistics of Spatial Predictor Variables in Windhoek ($N = 2,500$)}
\label{tab:summary_stats}
\small
\begin{tabular}{lccccc}
\toprule
\textbf{Spatial Predictor} & \textbf{Measurement Unit} & \textbf{Mean} & \textbf{Std. Dev.} & \textbf{Median} & \textbf{Min -- Max} \\
\midrule
\texttt{RoadDist} & Kilometers (km) & 2.839 & 2.366 & 2.228 & 0.023 -- 10.310 \\
\texttt{SettleDist} & Kilometers (km) & 8.086 & 4.455 & 8.124 & 0.067 -- 19.634 \\
\texttt{PopDensity} & Persons / km$^2$ & 1317.0 & 3331.4 & 51.8 & 0.100 -- 19539.8 \\
\texttt{Elevation} & Meters (ASL) & 1769.6 & 130.4 & 1767.0 & 1579.4 -- 2147.0 \\
\texttt{Slope} & Degrees ($^\circ$) & 25.70 & 9.39 & 27.82 & 0.780 -- 35.000 \\
\texttt{CBDDist} & Kilometers (km) & 8.074 & 3.164 & 8.238 & 0.156 -- 16.093 \\
\texttt{InfraProx} & Kilometers (km) & 5.999 & 3.239 & 5.910 & 0.086 -- 15.461 \\
\bottomrule
\end{tabular}
\end{table}

\subsection{Exploratory Spatial and Correlation Analysis}
To investigate linear relationships among spatial predictors and informal expansion ($Y$), Pearson correlation coefficients were calculated, as depicted in Figure~\ref{fig:heatmap}.

\begin{figure}[H]
\centering
\includegraphics[width=0.78\textwidth]{charts/correlation_heatmap.png}
\caption{Pearson Correlation Matrix of Spatial Predictors and Settlement Expansion}
\label{fig:heatmap}
\end{figure}

As shown in Figure~\ref{fig:heatmap}, informal settlement expansion ($Y$) exhibits strong negative correlations with \texttt{Slope} ($r = -0.56$) and \texttt{Elevation} ($r = -0.28$), confirming that expansion preferentially occurs on low-lying flat valley floors rather than steep mountain ridges. Conversely, \texttt{PopDensity} demonstrates a positive correlation ($r = +0.38$) with expansion, reflecting demographic spillover effects.

Sub-region spatial disaggregation further highlights marked geographic disparities in expansion risk, as shown in Figure~\ref{fig:suburb_breakdown}.

\begin{figure}[H]
\centering
\includegraphics[width=0.85\textwidth]{charts/suburb_expansion_breakdown.png}
\caption{Observed Informal Settlement Expansion Risk Rates across Windhoek Sub-Regions}
\label{fig:suburb_breakdown}
\end{figure}

The Havana / Goreangab Informal Corridor recorded the highest informal expansion rate ($54.2\%$), followed by Katutura / Hakahana / Okuryangava ($28.4\%$) and Otjomuise Extension ($19.8\%$). Formal eastern suburbs (Eros, Klein Windhoek, Ludwigsdorf) and the central CBD recorded $0.0\%$ informal expansion.

\section{Spatial Feature Dynamics and Distributional Analysis}
To evaluate how spatial predictor values differ between expansion areas ($Y=1$) and non-expansion areas ($Y=0$), side-by-side boxplots were constructed across all seven predictors (Figure~\ref{fig:boxplots}).

\begin{figure}[H]
\centering
\includegraphics[width=0.92\textwidth]{charts/predictor_boxplots.png}
\caption{Comparative Boxplots of Spatial Predictor Distributions by Settlement Expansion Status}
\label{fig:boxplots}
\end{figure}

The distributional comparison confirms that spatial units experiencing informal expansion are characterized by significantly lower mean distance to major roads ($1.15$~km vs $3.18$~km), closer proximity to existing informal settlements ($3.24$~km vs $9.06$~km), substantially higher population density ($4,215$ persons/km$^2$ vs $738$ persons/km$^2$), gentle terrain slopes (mean $12.8^\circ$ vs $28.3^\circ$), and lower elevation (mean $1,682$~m vs $1,787$~m ASL).

\section{Empirical Results: Logistic Regression Modeling}
A Binary Logistic Regression model was estimated to quantify the relationship between spatial predictors and the probability of settlement expansion $p_i = P(Y_i = 1)$. The logit link function is specified as:
\begin{equation}
\log\left(\frac{p_i}{1 - p_i}\right) = \beta_0 + \beta_1 \text{RoadDist}_i + \beta_2 \text{SettleDist}_i + \beta_3 \text{PopDensity}_i + \beta_4 \text{Elevation}_i + \beta_5 \text{Slope}_i + \beta_6 \text{CBDDist}_i + \beta_7 \text{InfraProx}_i
\end{equation}

The empirical parameter estimates obtained from the training set ($N_{\text{train}} = 2,000$) are presented in Table~\ref{tab:logit_results}.

\begin{table}[H]
\centering
\caption{Logistic Regression Parameter Estimates, Odds Ratios, and Statistical Significance}
\label{tab:logit_results}
\small
\begin{tabular}{lcccccc}
\toprule
\textbf{Feature Name} & \textbf{Beta ($\beta$)} & \textbf{Odds Ratio ($e^\beta$)} & \textbf{Std Error} & \textbf{z-Statistic} & \textbf{p-Value} & \textbf{Sig. ($p<0.05$)} \\
\midrule
(Intercept) & -6.9342 & 0.0010 & 0.5216 & -13.2946 & $< 0.0001$ & Yes *** \\
\texttt{RoadDist} & -1.1678 & 0.3111 & 0.2670 & -4.3733 & $< 0.0001$ & Yes *** \\
\texttt{SettleDist} & -0.9555 & 0.3846 & 0.4661 & -2.0500 & 0.0404 & Yes * \\
\texttt{PopDensity} & +0.4043 & 1.4983 & 0.1278 & +3.1644 & 0.0016 & Yes ** \\
\texttt{Elevation} & -1.9861 & 0.1372 & 0.3924 & -5.0618 & $< 0.0001$ & Yes *** \\
\texttt{Slope} & -3.9164 & 0.0199 & 0.3118 & -12.5606 & $< 0.0001$ & Yes *** \\
\texttt{CBDDist} & +0.3224 & 1.3804 & 0.1797 & +1.7943 & 0.0728 & No \\
\texttt{InfraProx} & +1.0915 & 2.9787 & 0.3172 & +3.4415 & 0.0006 & Yes *** \\
\bottomrule
\multicolumn{7}{l}{\footnotesize Significance codes: *** $p < 0.001$, ** $p < 0.01$, * $p < 0.05$.}
\end{tabular}
\end{table}

\subsection{Interpretation of Estimated Coefficients and Odds Ratios}
\begin{enumerate}
    \item \textbf{Terrain Slope ($\beta = -3.9164, p < 0.0001, \text{OR} = 0.0199$)}: Slope is the single strongest negative predictor of informal settlement expansion. Holding all other variables constant, a one standard deviation increase in terrain slope reduces the odds of settlement expansion by $98.01\%$, reflecting physical construction barriers on steep hillslopes.
    \item \textbf{Terrain Elevation ($\beta = -1.9861, p < 0.0001, \text{OR} = 0.1372$)}: Higher elevations significantly decrease expansion likelihood ($86.28\%$ odds reduction per std. dev.), confirming informal settlement preference for lower valley basins.
    \item \textbf{Road Proximity ($\beta = -1.1678, p < 0.0001, \text{OR} = 0.3111$)}: Distance to major arterial roads strongly suppresses expansion; being further from roads decreases expansion odds by $68.89\%$.
    \item \textbf{Settlement Proximity ($\beta = -0.9555, p = 0.0404, \text{OR} = 0.3846$)}: Spatial contagion is statistically significant: land parcels located further from existing informal settlements have $61.54\%$ lower odds of new expansion.
    \item \textbf{Population Density ($\beta = +0.4043, p = 0.0016, \text{OR} = 1.4983$)}: High population density exerts positive pressure, increasing expansion odds by $49.83\%$ per standard deviation.
\end{enumerate}

\section{Empirical Results: Random Forest Classifier}
To capture non-linear interactions and threshold effects, a Random Forest Classifier ($B = 100$ decision trees, maximum depth $= 8$) was trained on the spatial dataset. Gini impurity feature importances were extracted, as summarized in Table~\ref{tab:rf_importance} and Figure~\ref{fig:feature_importance}.

\begin{table}[H]
\centering
\caption{Random Forest Gini Feature Importance Breakdown}
\label{tab:rf_importance}
\small
\begin{tabular}{clcc}
\toprule
\textbf{Rank} & \textbf{Spatial Predictor Variable} & \textbf{Gini Importance Score} & \textbf{Relative Weight (\%)} \\
\midrule
1 & \texttt{Slope} & 0.4099 & 41.0\% \\
2 & \texttt{PopDensity} & 0.2458 & 24.6\% \\
3 & \texttt{SettleDist} & 0.1305 & 13.1\% \\
4 & \texttt{Elevation} & 0.0855 & 8.6\% \\
5 & \texttt{InfraProx} & 0.0454 & 4.5\% \\
6 & \texttt{CBDDist} & 0.0416 & 4.2\% \\
7 & \texttt{RoadDist} & 0.0411 & 4.1\% \\
\bottomrule
\end{tabular}
\end{table}

\begin{figure}[H]
\centering
\includegraphics[width=0.82\textwidth]{charts/feature_importance_bar.png}
\caption{Random Forest Gini Feature Importance Ranking for Informal Settlement Expansion}
\label{fig:feature_importance}
\end{figure}

Terrain slope dominates the Random Forest model with a Gini importance of $0.4099$ ($41.0\%$), followed by population density ($24.6\%$), distance to existing settlements ($13.1\%$), and elevation ($8.6\%$). Together, terrain constraints and demographic pressure account for over $78\%$ of total predictive importance.

\section{Model Performance Evaluation and Comparison}
Model performance was evaluated on an independent holdout test set ($N_{\text{test}} = 500$) and verified using 5-fold stratified cross-validation ($N = 2,500$). Performance metrics including Accuracy, Precision, Recall, F1-Score, and ROC-AUC are presented in Table~\ref{tab:model_comparison}.

\begin{table}[H]
\centering
\caption{Comparative Performance Metrics of Predictive Models}
\label{tab:model_comparison}
\small
\begin{tabular}{lcccccc}
\toprule
\textbf{Model} & \textbf{Accuracy} & \textbf{Precision} & \textbf{Recall} & \textbf{F1-Score} & \textbf{Test AUC} & \textbf{5-Fold CV AUC} \\
\midrule
Logistic Regression & 95.6\% & 85.1\% & 89.2\% & 0.871 & 0.983 & $0.986 \pm 0.003$ \\
\textbf{Random Forest Classifier} & \textbf{99.0\%} & \textbf{97.6\%} & \textbf{96.4\%} & \textbf{0.970} & \textbf{0.996} & \textbf{$0.998 \pm 0.002$} \\
Decision Tree (Benchmark) & 99.0\% & 97.6\% & 96.4\% & 0.970 & 0.997 & $0.984 \pm 0.009$ \\
\bottomrule
\end{tabular}
\end{table}

\begin{figure}[H]
\centering
\includegraphics[width=0.92\textwidth]{charts/roc_curves.png}
\caption{Receiver Operating Characteristic (ROC) and Precision-Recall Curves}
\label{fig:roc_curves}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.85\textwidth]{charts/confusion_matrices.png}
\caption{Confusion Matrix Heatmaps for Logistic Regression and Random Forest Models}
\label{fig:confusion_matrices}
\end{figure}

As shown in Table~\ref{tab:model_comparison} and Figures~\ref{fig:roc_curves}--\ref{fig:confusion_matrices}, the Random Forest Classifier demonstrated superior performance, achieving $99.0\%$ Test Accuracy, $97.6\%$ Precision, $96.4\%$ Recall, F1-Score of $0.970$, and a 5-fold cross-validated ROC-AUC of $0.998 \pm 0.002$.

\section{Spatial Prediction and Vulnerability Mapping in Windhoek}
Using the trained Random Forest Classifier, estimated expansion probabilities $p_i = P(Y_i = 1)$ were projected across all 2,500 grid cells to generate a continuous spatial vulnerability risk map for Windhoek, shown in Figure~\ref{fig:spatial_risk_map}.

\begin{figure}[H]
\centering
\includegraphics[width=0.90\textwidth]{charts/spatial_prediction_risk_map.png}
\caption{Predicted Spatial Vulnerability Risk Surface of Informal Settlement Expansion in Windhoek}
\label{fig:spatial_risk_map}
\end{figure}

\subsection{Identification of Critical Expansion Risk Corridors}
\begin{enumerate}
    \item \textbf{Critical High-Risk Zone ($P > 0.85$)}: Located in North-West Windhoek, encompassing Havana Extension 10, Goreangab Dam catchment basin, Otjomuise Extensions 4 \& 5, Babylon, and Kilimanjaro. These zones combine high population density ($>10,000$ persons/km$^2$), gentle slopes ($<12^\circ$), and close proximity ($<1.5$~km) to existing informal settlement nodes.
    \item \textbf{Moderate Expansion Buffer ($0.30 \le P \le 0.70$)}: Peri-urban buffer zones surrounding Katutura, Hakahana, and northern Otjomuise along Monte Christo Road and the Western Bypass corridor.
    \item \textbf{Zero-Risk / Protected Zones ($P < 0.10$)}: Windhoek Central Business District (CBD), formal southern industrial zones, and eastern mountainous ridges (Auas and Eros mountains) restricted by steep terrain ($>18^\circ$) and municipal land tenure enforcement.
\end{enumerate}

\section{Discussion of Findings and Urban Planning Implications}
The empirical results confirm that informal settlement expansion in Windhoek is governed by an interplay of physical terrain constraints, demographic pressure, and transport accessibility. In agreement with broader urban growth literature (Angel et al., 2020; Kuffer et al., 2020), slope and elevation act as rigid physical barriers. Informal dwellings expand laterally across gentle valley basins before encroaching onto moderate hillsides, avoiding steep mountain faces due to terrain instability and accessibility constraints.

Furthermore, the statistical significance of \texttt{SettleDist} ($\text{OR} = 0.3846$) and \texttt{RoadDist} ($\text{OR} = 0.3111$) supports the spatial contagion model: new informal migrants settle adjacent to existing social and kinship networks in Havana and Katutura and near primary transport arteries to minimize travel costs to central employment hubs.

\subsection{Strategic Urban Policy Recommendations}
\begin{enumerate}
    \item \textbf{Proactive Land Servicing in North-West Corridors}: Municipal planning authorities should prioritize rapid land tenure registration, layout planning, and basic service installation (communal water points, sanitation, access roads) in predicted high-risk zones (Havana, Goreangab, Otjomuise) before informal structures densify uncontrollably.
    \item \textbf{Integration of Predictive Machine Learning into Municipal GIS}: The City of Windhoek's Urban Planning Department should embed automated machine learning risk surface modeling into quarterly monitoring workflows, leveraging high-resolution satellite imagery updates.
    \item \textbf{Coordinated Infrastructure and Transport Planning}: Transportation planners must align road network expansion with informal settlement upgrading initiatives (such as the Informal Settlement Upgrading Project) to guide urban growth away from flood-prone catchment areas and steep erosion-sensitive slopes.
\end{enumerate}

\section{Chapter Summary}
This chapter presented the empirical results and discussion for predicting informal settlement expansion in Windhoek using spatial analysis and machine learning. Through a dataset of 2,500 spatial grid units, terrain slope, population density, distance to existing informal settlements, and road proximity were identified as the primary drivers of expansion risk. The Random Forest Classifier achieved exceptional predictive performance ($99.0\%$ Accuracy, $0.998$ CV ROC-AUC), outperforming Binary Logistic Regression ($95.6\%$ Accuracy, $0.986$ CV ROC-AUC). High-resolution spatial risk maps successfully delineated critical expansion hotspots in Havana, Goreangab, and Otjomuise. The final chapter (Chapter 5) will synthesize these findings, address the research objectives, highlight contributions, and propose future research directions.

\end{document}
"""
    tex_path = os.path.join(project_dir, "chapter4_results.tex")
    with open(tex_path, 'w', encoding='utf-8') as f:
        f.write(tex_content)
    print(f"-> Successfully saved LaTeX document to: {tex_path}")


def main():
    project_dir = r"C:\Users\220078548\.gemini\antigravity-ide\scratch\windhoek_informal_settlements"
    print("Generating Chapter 4 Word Document, Markdown, and LaTeX files...")
    generate_word_doc(project_dir)
    generate_markdown_doc(project_dir)
    generate_latex_doc(project_dir)
    print("All Chapter 4 documents generated successfully!")

if __name__ == '__main__':
    main()
