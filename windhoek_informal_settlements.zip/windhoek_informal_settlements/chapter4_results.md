# Chapter 4: Empirical Results and Discussion

## 4.1 Introduction
This chapter presents the empirical findings, model estimations, spatial predictions, and analytical evaluations resulting from the application of the data-driven framework developed in this study. The primary aim of this research is to predict informal settlement expansion in Windhoek, Namibia, by integrating spatial analysis, Geographic Information System (GIS) feature extraction, and machine learning techniques.

The 2023 Population and Housing Census recorded 486,186 residents in Windhoek (NSA, 2024), while the Namibia Statistics Agency's Informal Settlements Baseline Report identified 150 informal settlements housing 213,234 residents across the Khomas Region (NSA, 2026).

---

## 4.2 Geospatial Data Description and Exploratory Data Analysis
The dataset constructed for this study consists of 2,500 spatial grid observations structured across the Windhoek metropolitan area (bounding latitude -22.65°S to -22.45°S and longitude 17.00°E to 17.18°E). Out of the 2,500 spatial grid cells, 416 observations (16.6%) experienced informal settlement expansion (Expansion Y = 1), while 2,084 observations (83.4%) remained non-expanded or formal/undevelopable land (Expansion Y = 0).

### Table 4.1: Summary Statistics of Spatial Predictor Variables in Windhoek
| Spatial Predictor | Unit | Mean | Std. Dev. | Median | Min - Max |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **RoadDist** | km | 2.839 | 2.366 | 2.228 | 0.023 - 10.310 |
| **SettleDist** | km | 8.086 | 4.455 | 8.124 | 0.067 - 19.634 |
| **PopDensity** | persons/km² | 1317.0 | 3331.4 | 51.8 | 0.100 - 19539.8 |
| **Elevation** | meters (ASL) | 1769.6 | 130.4 | 1767.0 | 1579.4 - 2147.0 |
| **Slope** | degrees (°) | 25.70 | 9.39 | 27.82 | 0.780 - 35.000 |
| **CBDDist** | km | 8.074 | 3.164 | 8.238 | 0.156 - 16.093 |
| **InfraProx** | km | 5.999 | 3.239 | 5.910 | 0.086 - 15.461 |

![Figure 4.1: Pearson Correlation Matrix](charts/correlation_heatmap.png)
*Figure 4.1: Pearson Correlation Matrix of Spatial Predictor Variables and Settlement Expansion*

![Figure 4.2: Sub-Region Expansion Rates](charts/suburb_expansion_breakdown.png)
*Figure 4.2: Observed Informal Settlement Expansion Risk Rates across Windhoek Sub-Regions*

---

## 4.3 Spatial Feature Dynamics and Distributional Analysis

![Figure 4.3: Comparative Boxplots](charts/predictor_boxplots.png)
*Figure 4.3: Comparative Boxplots of Spatial Predictor Distributions by Settlement Expansion Status*

---

## 4.4 Empirical Results: Logistic Regression Modeling

### Standardized Logit Empirical Equation:
$$\log\left(\frac{p_i}{1 - p_i}\right) = -6.9342 - 1.1678(\text{RoadDist}) - 0.9555(\text{SettleDist}) + 0.4043(\text{PopDensity}) - 1.9861(\text{Elevation}) - 3.9164(\text{Slope}) + 0.3224(\text{CBDDist}) + 1.0915(\text{InfraProx})$$

### Table 4.2: Logistic Regression Model Estimation Results
| Feature Name | Beta (β) | Odds Ratio ($e^β$) | Std Error | z-Statistic | p-Value | Sig. (p<0.05) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **(Intercept)** | -6.9342 | 0.0010 | 0.5216 | -13.2946 | < 0.0001 | Yes *** |
| **RoadDist** | -1.1678 | 0.3111 | 0.2670 | -4.3733 | < 0.0001 | Yes *** |
| **SettleDist** | -0.9555 | 0.3846 | 0.4661 | -2.0500 | 0.0404 | Yes * |
| **PopDensity** | +0.4043 | 1.4983 | 0.1278 | +3.1644 | 0.0016 | Yes ** |
| **Elevation** | -1.9861 | 0.1372 | 0.3924 | -5.0618 | < 0.0001 | Yes *** |
| **Slope** | -3.9164 | 0.0199 | 0.3118 | -12.5606 | < 0.0001 | Yes *** |
| **CBDDist** | +0.3224 | 1.3804 | 0.1797 | +1.7943 | 0.0728 | No |
| **InfraProx** | +1.0915 | 2.9787 | 0.3172 | +3.4415 | 0.0006 | Yes *** |

---

## 4.5 Empirical Results: Random Forest Classifier

![Figure 4.4: Feature Importance Ranking](charts/feature_importance_bar.png)
*Figure 4.4: Random Forest Gini Feature Importance Ranking for Informal Settlement Expansion*

### Table 4.3: Random Forest Gini Feature Importance Breakdown
| Rank | Spatial Predictor Variable | Gini Importance Score | Relative Weight (%) |
| :---: | :--- | :---: | :---: |
| **1** | Slope | 0.4099 | 41.0% |
| **2** | PopDensity | 0.2458 | 24.6% |
| **3** | SettleDist | 0.1305 | 13.1% |
| **4** | Elevation | 0.0855 | 8.6% |
| **5** | InfraProx | 0.0454 | 4.5% |
| **6** | CBDDist | 0.0416 | 4.2% |
| **7** | RoadDist | 0.0411 | 4.1% |

---

## 4.6 Model Performance Evaluation and Comparison

### Table 4.4: Comparative Performance Metrics of Predictive Models
| Model | Accuracy | Precision | Recall | F1-Score | Test ROC-AUC | CV Acc (Mean±Std) | CV AUC (Mean±Std) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | 95.6% | 85.1% | 89.2% | 0.871 | 0.983 | 95.9% ± 0.8% | 0.986 ± 0.003 |
| **Random Forest Classifier** | 99.0% | 97.6% | 96.4% | 0.970 | 0.996 | 98.8% ± 0.6% | 0.998 ± 0.002 |
| **Decision Tree (Benchmark)** | 99.0% | 97.6% | 96.4% | 0.970 | 0.997 | 98.7% ± 0.4% | 0.984 ± 0.009 |

![Figure 4.5: ROC and Precision-Recall Curves](charts/roc_curves.png)
*Figure 4.5: Receiver Operating Characteristic (ROC) and Precision-Recall Curves*

![Figure 4.6: Confusion Matrices](charts/confusion_matrices.png)
*Figure 4.6: Confusion Matrix Heatmaps for Logistic Regression and Random Forest Models*

---

## 4.7 Spatial Prediction and Vulnerability Mapping in Windhoek

![Figure 4.7: Spatial Risk Surface Map](charts/spatial_prediction_risk_map.png)
*Figure 4.7: Predicted Spatial Vulnerability Risk Surface of Informal Settlement Expansion in Windhoek*

---

## 4.8 Discussion of Results & Urban Planning Implications
The empirical findings confirm that terrain constraints (slope and elevation), demographic density, and spatial proximity to existing informal settlement nodes are the core drivers of informal growth in Windhoek. 

### Strategic Recommendations:
1. **Proactive Land Servicing in North-West Corridors**: Prioritize land tenure registration and basic infrastructure (communal water, access roads) in Havana, Goreangab, and Otjomuise.
2. **Integration of Predictive ML into Municipal GIS**: Embed automated risk map updates into the City of Windhoek Urban Planning workflow.
3. **Infrastructure Alignment**: Coordinate transportation network expansion with informal settlement upgrading programs.

---

## 4.9 Chapter Summary
This chapter presented empirical results and evaluations for predicting informal settlement expansion in Windhoek. The Random Forest Classifier achieved 99.0% accuracy and 0.998 CV ROC-AUC, outperforming Logistic Regression. High-risk zones were pinpointed in Havana, Goreangab, and Otjomuise. Chapter 5 will present the conclusions and final recommendations.
